import { api } from '../lib/api';

export const cartApi = {
  async getCart() {
    return api.get('/api/carts');
  },

  async addToCart(payload) {
    return api.post('/api/carts', payload);
  },

  async updateCartItem(menuItemId, payload) {
    return api.put(`/api/carts/${menuItemId}`, payload);
  },

  async removeFromCart(menuItemId) {
    return api.request(`/api/carts/${menuItemId}`, {
      method: 'DELETE',
    });
  },

  async clearCart() {
    return api.request('/api/carts', {
      method: 'DELETE',
    });
  },
};
